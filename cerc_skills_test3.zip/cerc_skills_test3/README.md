Software/libraries and their versions
1. Python - 3.7.7
2. VerifyBamID2 - Checked out from master branch
3. Pandas - 1.3.1
4. os
5. Operator
6. Math
7. Matplotlib - 3.4.2
8. Mpl_toolkits 
9. WDL - verion 1.0
10. Cromwell - cromwell-85.jar
11. Java - 14.0.1

Compilation instructions
I followed the instructions provided at https://github.com/Griffan/VerifyBamID to install and compile VerifyBamID after cloning the software.

Operating System used
I used MacOS, however it should work well in any UNIX/LINUX environment.

Steps to run the tool
1. Download Cromwell https://github.com/broadinstitute/cromwell/releases/download/85/cromwell-85.jar & Womtool https://github.com/broadinstitute/cromwell/releases/download/85/womtool-85.jar (for sanity checking)
2. Download GRCh38_full_analysis_set_plus_decoy_hla.fa, GRCh38_full_analysis_set_plus_decoy_hla.fa.fai and git clone https://github.com/CERC-Genomic-Medicine/skills_test_3.git
3. Edit work.json file to include the following paths and setting as input to the workflow:
   dna.verify_cram_id_tool - Path to VerifyBamID software
   dna.ref_fasta - Path to downloaded GRCh38_full_analysis_set_plus_decoy_hla.fa
   dna.ref_pc - Path to 1000g.phase3.10k.b38.vcf.gz.dat.V
   dna.ref_population - Path to 1000G_reference_populations.txt
   dna.input_dir - Path to directory with input CRAM and CRAI files
   dna.num_pc - 4
   dna.out_dir - Path to output directory
4. Run the workflow using the following command (This assumes jar, wdl and json are all the same directory):
   java -jar cromwell-85.jar run dna_contaminate_ancestry.wdl --inputs work.json
